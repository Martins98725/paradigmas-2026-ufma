#pograma para calculo de medias, notas de alunos
#nota, media 
#float nota1 
#float nota2 
#float nota3 
# uma funcao de media, uma funcao de total notas e uma funcao de estado aprovado reporvado ( se colocar uma dentro da outra) 
#boleano isAprovado
#float media 
#string nomeAluno

#nomeAluno = input("Insira a seu nome")
#float nota1 = input("Insira a primeira nota")
#float nota2 = input("Insira a segunda nota")
#float nota3 = input("Insira a terceira nota")
#utilizando função de alta ordem, uma dentro da outra seguindo os preceitos do paradigma funcional   
def calcularTotal (somaNotas):
    return sum(somaNotas)

     
def calcularMedia (notas):
    return total
    


def validarEstadoAluno(media)
    if media >= 7.0:
        print("Aprovado: ", media)
    else:
        print("Reprovado")

    
int main():
  nota1 = input("Insira a primeira nota")
  nota2 = input("Insira a segunda nota")
  nota3 = input("Insira a terceira nota")


    
    
